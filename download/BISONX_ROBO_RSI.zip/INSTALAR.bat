@echo off
chcp 65001 >nul
title Instalar Robo BISONX - 1 clique
color 0A
setlocal
set "ROBO=BISONX_ROBO_RSI.mq5"
set "TERM="
for /d %%D in ("%APPDATA%\MetaQuotes\Terminal\*") do (
  if exist "%%~D\MQL5\Experts" set "TERM=%%~D"
)
if not defined TERM (
  echo.
  echo  MetaTrader 5 nao encontrado neste computador.
  echo  Instale o MT5 em www.metatrader5.com e rode este arquivo de novo.
  echo.
  pause
  exit /b 1
)
copy /y "%~dp0BISONX_ROBO_RSI.mq5" "%TERM%\MQL5\Experts\BISONX_ROBO_RSI.mq5" >nul
set "ED=C:\Program Files\MetaTrader 5\MetaEditor64.exe"
if not exist "%ED%" if exist "C:\Program Files (x86)\MetaTrader 5\MetaEditor64.exe" set "ED=C:\Program Files (x86)\MetaTrader 5\MetaEditor64.exe"
echo.
echo  Compilando BISONX_ROBO_RSI.mq5 ... aguarde
"%ED%" /compile:"%TERM%\MQL5\Experts\BISONX_ROBO_RSI.mq5" /log:"%TERM%\MQL5\Experts\BISONX_ROBO_RSI.mq5.compilacao.log"
if exist "%TERM%\MQL5\Experts\BISONX_ROBO_RSI.mq5.compilacao.log" (
  findstr /C:"error" "%TERM%\MQL5\Experts\BISONX_ROBO_RSI.mq5.compilacao.log" >nul && (
    echo.
    echo  OCORREU UM ERRO NA COMPILACAO.
    echo  Envie este arquivo para o suporte: BISONX_ROBO_RSI.mq5.compilacao.log
  ) || (
    echo  COMPILADO COM SUCESSO - seu robo esta pronto!
  )
)
echo.
echo  Como usar no MT5:
echo   1. Abra o Navegador (tecla F10 ou Ctrl+N) e veja "Especialistas"
echo   2. Arraste BISONX_ROBO_RSI.mq5 para dentro do grafico
echo   3. Clique OK e depois permita a automacao (botao "Algo Trading")
echo.
echo  Dica: teste antes em conta demo ou no Testador de Estrategia.
echo.
pause
