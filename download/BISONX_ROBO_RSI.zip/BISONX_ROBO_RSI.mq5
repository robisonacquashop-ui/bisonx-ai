//+------------------------------------------------------------------+
//|                                           BISONX_ROBO_RSI.mq5 |
//|                                 Gerado pelo BISONX - gratuito p/ teste |
//+------------------------------------------------------------------+
#property copyright "BISONX"
#property version      "1.00"
#property strict

#include <Trade\Trade.mqh>
CTrade trade;

//---------------------- ENTRADA ----------------------
input int   RsiPeriod = 14;   // Periodo do RSI
input int   NivelSuperior = 70; // Sobrecompra
input int   NivelInferior = 30; // Sobrevenda
input double LotSize = 0.10;
input int   MagicNum = 1341415052;
input double StopLoss   = 200;   // Stop Loss em pontos (0 = desligado)
input double TakeProfit = 300;   // Take Profit em pontos (0 = desligado)

int    hRsi;
double r[1];

int OnInit()
  {
   hRsi = iRSI(_Symbol, _Period, RsiPeriod, PRICE_CLOSE);
   if(hRsi==INVALID_HANDLE) return(INIT_FAILED);
   trade.SetExpertMagicNumber(MagicNum);
   return(INIT_SUCCEEDED);
  }

void OnTick()
  {
   if(CopyBuffer(hRsi,0,0,1,r)!=1) return;
   bool sobrecompra = (r[0] > NivelSuperior);
   bool sobrevenda  = (r[0] < NivelInferior);
   if(sobrevenda  && !_TemCompra(MagicNum)) _Abre("buy");
   if(sobrecompra && !_TemVenda(MagicNum)) _Abre("sell");
  }

//---------------------- AUXILIARES ----------------------
bool _TemCompra(int _magic)
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
       ulong t=PositionGetTicket(i);
       if(t==0) continue;
       if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
       if(PositionGetInteger(POSITION_MAGIC)!=_magic) continue;
       if(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)
          return(true);
     }
   return(false);
  }

bool _TemVenda(int _magic)
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
       ulong t=PositionGetTicket(i);
       if(t==0) continue;
       if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
       if(PositionGetInteger(POSITION_MAGIC)!=_magic) continue;
       if(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_SELL)
          return(true);
     }
   return(false);
  }

int _ContaAbertas(int _magic)
  {
   int c=0;
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
       ulong t=PositionGetTicket(i);
       if(t==0) continue;
       if(PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
       if(PositionGetInteger(POSITION_MAGIC)!=_magic) continue;
       c++;
     }
   return(c);
  }

void _Abre(string tipo)
  {
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(tipo=="buy")
     {
       double sl = StopLoss>0 ? ask - StopLoss*_Point : 0;
       double tp = TakeProfit>0 ? ask + TakeProfit*_Point : 0;
       trade.Buy(LotSize, _Symbol, ask, sl, tp, "BISONX");
     }
   else
     {
       double sl = StopLoss>0 ? bid + StopLoss*_Point : 0;
       double tp = TakeProfit>0 ? bid - TakeProfit*_Point : 0;
       trade.Sell(LotSize, _Symbol, bid, sl, tp, "BISONX");
     }
  }